# KMB Library 2.0 : Livrable 2 (Windows, Linux, macOS)

KMB Library audite un poste de travail **Windows 10/11, Linux ou macOS** : sécurité, Wi-Fi, logiciels,
performance, santé matérielle, stockage et doublons. Les résultats sont livrés sous deux formes :
un **site web** (guide d'installation + analyse du rapport dans le navigateur, publiable en ligne) et une **API JSON** (FastAPI).

**Parcours d'un utilisateur :** il suit le guide du site (installer Python, puis `python -m pip install https://<site>/telechargements/kmb-library.zip`), lance `python -m kmb_library scan`, récupère son rapport
`KMB-rapport_<PC>_<date>_<heure>.json` dans **Documents\KMB Library**, puis le téléverse sur le site, qui l'affiche
sans rien envoyer ni conserver.

| Document | Contenu |
|---|---|
| [One-Page-Projet.md](One-Page-Projet.md) | Besoin, solution, valeur, limites |
| [One-Page-Processus.md](One-Page-Processus.md) | Diagramme du processus et reprise |
| [Notes.md](Notes.md) | Choix, essais, usage de l'IA, apprentissages |
| [Verifications.md](Verifications.md) | Tableau des vérifications et preuves |
| [Presentation.md](Presentation.md) | Déroulé de la présentation et de la démonstration |
| [exemples/](exemples/) | Données avant/après, réponses de l'API, captures, simulations |
| [DEPLOIEMENT.md](DEPLOIEMENT.md) | Publier le site (GitHub Pages, Hostinger) et préparer le ZIP à télécharger |

## 1. Installation

Prérequis : Python 3.10 ou plus récent.

```bash
cd livrable_2
python -m venv .venv
# Windows : .venv\Scripts\activate      Linux / macOS : source .venv/bin/activate
pip install -e ".[dev]"
```

Assistant IA (facultatif) : copier `.env.example` en `.env` et renseigner `XAI_API_KEY` (clé Grok de xAI).

## 2. Lancer un audit

Après l'installation (section 1, ou guide du site) :
```bash
kmb scan                         # 1 à 3 minutes ; le système est détecté automatiquement
kmb scan --nom "PC de Marie"     # nom affiché dans le rapport et dans le nom du fichier
kmb scan --anonymiser            # masque machine, comptes, IP, SSID Wi-Fi, chemins personnels
kmb scan --dossiers ~/Photos     # doublons cherchés dans un dossier précis
kmb scan --sans-maj --budget 30  # plus rapide
kmb scan --sortie data           # enregistre dans ./data (lu par l'API locale) au lieu de Documents
```

Fichiers produits (par défaut dans **Documents\KMB Library**, dossier ouvert automatiquement à la fin ; détail dans [data/LISEZMOI.md](data/LISEZMOI.md)) :

| Fichier | Rôle |
|---|---|
| `KMB-rapport_PC-de-Marie_2026-10-18_14h30.json` | **à téléverser** sur le site |
| `KMB-rapport_PC-de-Marie_2026-10-18_14h30.html` | à lire d'un double-clic (imprimable en PDF) |
| `donnees-brutes/donnees-brutes_PC-de-Marie_2026-10-18_14h30.json` | données non traitées (vérification) |

Droits élevés (facultatifs, pour vérifier **tous** les contrôles) : « Exécuter en tant qu'administrateur » sous Windows,
`sudo kmb scan` sous Linux et macOS. Sans ces droits, les contrôles concernés sont « non vérifiables » et ne comptent pas
dans le score. Le scan est **en lecture seule**.

## 3. Site web et API

```bash
uvicorn api.main:app --reload
```

* **Site public** : http://127.0.0.1:8000/ : accueil, guide d'installation pas à pas, « Analyser mon rapport » (le fichier est lu par le navigateur, rien n'est envoyé), questions fréquentes. Le même dossier `web/` se publie tel quel (voir [DEPLOIEMENT.md](DEPLOIEMENT.md)).
* **Tableau de bord relié à l'API** : http://127.0.0.1:8000/?mode=serveur : rapports du dossier `data/` (produits avec `kmb scan --sortie data` ou téléversés vers l'API), plan IA Grok.
* **Documentation interactive de l'API** : http://127.0.0.1:8000/docs

| Endpoint | Rôle | Paramètres |
|---|---|---|
| `GET /scans` | Historique des scans | `machine`, `systeme`, `date_min`, `date_max`, `score_max`, `limit` |
| `GET /scans/{scan_id}` | Rapport complet (`dernier` = plus récent) | `scan_id` |
| `GET /scans/{scan_id}/findings` | Filtrer les problèmes | `severite` (répétable), `domaine`, `categorie`, `statut`, `recherche`, `limit` |
| `GET /scans/{scan_id}/logiciels` | Logiciels et cycle de vie | `recherche`, `cycle_de_vie`, `taille_min_mo`, `limit` |
| `GET /comparaison` | Avant / après | `ancien`, `nouveau` |
| `GET /statistiques` | Indicateurs, évolution, répartition par système | `machine`, `systeme` |
| `GET /scans/{scan_id}/rapport.html` | Rapport imprimable (« Enregistrer en PDF ») | `scan_id` |
| `POST /scans` · `DELETE /scans/{id}` | Téléverser / supprimer un rapport | corps JSON |
| `GET/POST /scans/{scan_id}/plan-ia` | Plan de correction Grok, vérifié | `regenerer` |
| `GET /connaissances[/{id}]` | Explication d'un contrôle (56) | `domaine`, `recherche` |

Erreurs : `404` introuvable, `422` paramètre invalide (avec le champ en cause), `409` doublon, `503` IA non configurée, `502` erreur Grok.

## 4. Autres commandes

```bash
kmb comparer A.json B.json                 # avant / après en console
kmb envoyer A.json --api http://serveur:8000
kmb plan-ia A.json                         # plan IA Grok en console
pytest                                     # 59 tests (dont Linux et macOS simulés)
python scripts/construire_telechargements.py   # ZIP du code -> web/telechargements (--exe : programme Windows, non publié)
python scripts/capturer_exemples.py        # réponses de l'API -> exemples/appels_api
python scripts/capturer_ecrans.py          # captures du tableau de bord -> exemples/captures
python scripts/generer_simulations.py      # rapports Linux/macOS simulés -> exemples/simulations
```

Validation sur de vraies machines Linux et macOS : le workflow [.github/workflows/kmb-multiplateforme.yml](.github/workflows/kmb-multiplateforme.yml)
lance les tests et un `kmb scan` réel sur des runners GitHub Windows, Ubuntu et macOS dès que le dossier est poussé sur GitHub.

## 5. Organisation du code

| Dossier | Rôle |
|---|---|
| `kmb_library/collectors/windows/`, `linux/`, `macos/` | **A. Collecte** propre à chaque système (9 collecteurs chacun), même forme de données en sortie |
| `kmb_library/collectors/common.py`, `wifi.py`, `hardware.py`, `duplicates.py` | **A. Collecte** commune (psutil, Wi-Fi, batterie, doublons) |
| `kmb_library/enrich/endoflife.py` | **A. Source externe** : cycle de vie de l'OS et des logiciels (API endoflife.date, cache 7 jours) |
| `kmb_library/rules/` | **B. Traitement** : règles + `knowledge_base.json` (56 contrôles, variantes `*_linux` / `*_macos`) |
| `kmb_library/core/` | Modèles, scores, comparaison, anonymisation, orchestration |
| `kmb_library/ai/grok.py` | Plan IA (Grok) avec vérification des réponses |
| `api/` | **C. Livraison** : API FastAPI (lit les fichiers JSON de `data/`) |
| `web/` | **C. Livraison** : site statique (guide + analyse dans le navigateur ; mode serveur via l'API) |
| `kmb_library/scanner_app.py` | Programme `KMB-Scanner.exe` (préparé pour une future version signée ; non publié) |
| `tests/` | 59 tests ; `tests/fixtures/` contient des sorties Linux/macOS représentatives |
