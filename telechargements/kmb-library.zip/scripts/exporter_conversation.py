"""Exporte une conversation Claude Code (fichier .jsonl) en Markdown lisible.

Usage : python scripts/exporter_conversation.py CHEMIN.jsonl SORTIE.md

- Les messages de l'étudiant et de l'IA sont conservés intégralement, dans l'ordre d'origine.
- Les actions de l'IA (lecture de fichiers, commandes, écriture de code) sont résumées en une ligne
  pour garder le document lisible ; le code produit se trouve dans le projet lui-même.
- Les rappels techniques injectés par l'outil (balises <system-reminder>) sont retirés.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

_REMINDER = re.compile(r"<system-reminder>.*?</system-reminder>", re.S)


def _action(block: dict) -> str:
    name = block.get("name", "outil")
    inp = block.get("input") or {}
    if name in ("Write", "Edit", "Read"):
        path = Path(str(inp.get("file_path", ""))).name
        verb = {"Write": "Écriture du fichier", "Edit": "Modification du fichier", "Read": "Lecture du fichier"}[name]
        return f"{verb} `{path}`"
    if name in ("Bash", "PowerShell"):
        return f"Commande : {inp.get('description') or str(inp.get('command', ''))[:80]}"
    if name in ("WebFetch", "WebSearch"):
        return f"Recherche web : {inp.get('url') or inp.get('query')}"
    return f"Outil {name}"


def export(src: Path, dst: Path) -> int:
    lines = ["# Conversation complète - KMB Library", "",
             "Outil : Claude Code (extension VS Code), modèle Claude Opus.",
             "Fichiers fournis à l'IA au départ : énoncé du projet, consignes des livrables 1 et 2, "
             "`projet.txt` (cahier des charges CyberAudit AI rédigé par l'étudiant).",
             "Les actions techniques de l'IA sont résumées entre crochets ; le code complet est dans le projet.", ""]
    count = 0
    pending_actions: list[str] = []

    def flush():
        if pending_actions:
            lines.append("> " + "  \n> ".join(f"[{a}]" for a in pending_actions))
            lines.append("")
            pending_actions.clear()

    for raw in src.read_text(encoding="utf-8").splitlines():
        d = json.loads(raw)
        kind = d.get("type")
        if kind not in ("user", "assistant") or d.get("isMeta"):
            continue
        content = d["message"]["content"]
        blocks = [{"type": "text", "text": content}] if isinstance(content, str) else content
        for b in blocks:
            if b.get("type") == "text":
                text = _REMINDER.sub("", b["text"]).strip()
                if not text or text.startswith("<command-") or text == "Tool loaded.":
                    continue
                flush()
                who = "Étudiant" if kind == "user" else "IA (Claude)"
                lines += [f"### {who}", "", text, ""]
                count += 1
            elif b.get("type") == "tool_use":
                pending_actions.append(_action(b))
    flush()
    dst.write_text("\n".join(lines), encoding="utf-8")
    return count


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        raise SystemExit(2)
    n = export(Path(sys.argv[1]), Path(sys.argv[2]))
    print(f"{n} messages exportés vers {sys.argv[2]}")
