"""Collecte : fichiers en double (taille -> empreinte partielle -> SHA-256) et noms de copies.

Les fichiers « en ligne uniquement » (OneDrive) sont ignorés pour ne pas les télécharger.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
from collections import defaultdict
from pathlib import Path

from kmb_library.core.context import ScanContext
from kmb_library.core.fswalk import FileEntry, WalkState, user_folders, walk_files

NAME = "duplicates"
LABEL = "Doublons"

CATEGORIES = {
    "documents": {".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt", ".odt", ".txt", ".csv"},
    "musique": {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"},
    "videos": {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm"},
    "images": {".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic", ".bmp"},
    "archives": {".zip", ".rar", ".7z", ".iso", ".msi", ".exe"},
}
EXT_CATEGORY = {ext: cat for cat, exts in CATEGORIES.items() for ext in exts}
MIN_SIZE = 1024
_CHUNK = 64 * 1024
MAX_GROUPS_REPORTED = 100

# « Film (1).mp4 », « Film - copie.mp4 », « photo_copy.jpg », « Copie de rapport.docx », « rapport-final-v2.docx »
_COPY_PATTERNS = [
    r"^(copie de|copy of)\s+",
    r"\s*[-_ ]\s*(copie|copy)(\s*\(\d+\))?$",
    r"\s*\(\d+\)$",
    r"[-_ ]?(final|finale|def|definitif)$",
    r"[-_ ]?v\d+$",
]


def normalize_name(filename: str) -> str:
    stem = Path(filename).stem.lower().strip()
    previous = None
    while previous != stem:
        previous = stem
        for pat in _COPY_PATTERNS:
            stem = re.sub(pat, "", stem).strip()
    return stem + Path(filename).suffix.lower()


def _hash(path: str, partial: bool) -> str | None:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            if partial:
                h.update(fh.read(_CHUNK))
                size = os.fstat(fh.fileno()).st_size
                if size > 2 * _CHUNK:
                    fh.seek(-_CHUNK, os.SEEK_END)
                    h.update(fh.read(_CHUNK))
            else:
                for block in iter(lambda: fh.read(1024 * 1024), b""):
                    h.update(block)
    except OSError:
        return None
    return h.hexdigest()


def find_duplicates(roots: list[Path], budget_s: float) -> dict:
    """Algorithme en 3 passes pour éviter de hacher tous les fichiers."""
    deadline = time.monotonic() + budget_s
    state = WalkState()
    by_size: dict[int, list[FileEntry]] = defaultdict(list)
    by_name: dict[str, list[FileEntry]] = defaultdict(list)
    skipped_cloud = 0
    for f in walk_files(roots, deadline, state):
        ext = Path(f.path).suffix.lower()
        if ext not in EXT_CATEGORY or f.size < MIN_SIZE:
            continue
        if f.cloud_only:
            skipped_cloud += 1
            continue
        by_size[f.size].append(f)
        by_name[normalize_name(Path(f.path).name)].append(f)

    groups = []
    hashed = 0
    for size, files in by_size.items():
        if len(files) < 2 or time.monotonic() > deadline + budget_s:  # hachage : budget supplémentaire
            continue
        partial: dict[str, list[FileEntry]] = defaultdict(list)
        for f in files:
            ph = _hash(f.path, partial=True)
            if ph:
                partial[ph].append(f)
        for candidates in partial.values():
            if len(candidates) < 2:
                continue
            full: dict[str, list[FileEntry]] = defaultdict(list)
            for f in candidates:
                fh = _hash(f.path, partial=False)
                hashed += 1
                if fh:
                    full[fh].append(f)
            for digest, same in full.items():
                if len(same) > 1:
                    ext = Path(same[0].path).suffix.lower()
                    ordered = sorted(same, key=lambda f: f.mtime)  # le plus ancien = original présumé
                    groups.append({
                        "sha256": digest,
                        "size_bytes": size,
                        "category": EXT_CATEGORY.get(ext, "autres"),
                        "count": len(same),
                        "wasted_bytes": size * (len(same) - 1),
                        "files": [f.path for f in ordered],
                    })
    groups.sort(key=lambda g: g["wasted_bytes"], reverse=True)
    dup_paths = {p for g in groups for p in g["files"]}

    similar = []
    for norm, files in by_name.items():
        others = [f for f in files if f.path not in dup_paths]
        if len(files) > 1 and len(others) > 1:
            similar.append({"normalized_name": norm, "count": len(files), "files": [f.path for f in files][:10]})
    similar.sort(key=lambda s: s["count"], reverse=True)

    by_cat: dict[str, dict] = {}
    for g in groups:
        c = by_cat.setdefault(g["category"], {"groups": 0, "wasted_bytes": 0})
        c["groups"] += 1
        c["wasted_bytes"] += g["wasted_bytes"]
    return {
        "roots": [str(r) for r in roots],
        "files_scanned": state.files,
        "cloud_only_skipped": skipped_cloud,
        "files_hashed": hashed,
        "truncated": state.truncated,
        "group_count": len(groups),
        "duplicate_files": sum(g["count"] - 1 for g in groups),
        "wasted_bytes": sum(g["wasted_bytes"] for g in groups),
        "by_category": by_cat,
        "groups": groups[:MAX_GROUPS_REPORTED],
        "similar_names": similar[:50],
    }


def collect(ctx: ScanContext) -> dict:
    if not ctx.duplicates:
        return {"skipped": True}
    roots = ctx.duplicate_dirs or list(user_folders().values())
    return find_duplicates(roots, ctx.storage_time_budget_s / 2)
