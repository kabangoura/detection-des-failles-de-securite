# KMB Library 2.2 : Livrable 2 (Windows, Linux, macOS)

KMB Library audite un poste de travail **Windows 10/11, Linux ou macOS** : sécurité, Wi-Fi, logiciels,
performance, santé matérielle, stockage et doublons. Les résultats sont livrés sous deux formes :
un **site web** en français et en anglais (guide d'installation + analyse du rapport dans le navigateur + assistant IA facultatif),
publié sur https://kabangoura.github.io/detection-des-failles-de-securite/ ([English](https://kabangoura.github.io/detection-des-failles-de-securite/en/)),
et une **API JSON** (FastAPI). Le code est publié sur [GitHub](https://github.com/kabangoura/detection-des-failles-de-securite) et sur [PyPI](https://pypi.org/project/kmb-library/).

**Nouveautés de la version 2.2 :**
* **Assistant IA sur le site** (Groq, avec accord de l'utilisateur) : expliquer un problème, résumer le rapport, plan de correction,
  questions libres, commentaire avant/après ; relais Cloudflare qui garde la clé secrète ; chaque réponse vérifiée (étapes et commandes).
* **Site en anglais** (`/en/`, bouton FR / EN) : interface, 57 fiches et 236 commandes traduites.
* **Vrais tests sur Windows, Linux et macOS** (GitHub Actions, Python 3.10 et 3.13) à chaque modification, avec un vrai scan.
* **Publication automatique sur PyPI** (sans clé) quand une version est publiée sur GitHub.
* **« Nouvelle version disponible »** affiché au début et à la fin du scan.

**Parcours d'un utilisateur :** il suit le guide du site (installer Python, puis `python -m pip install kmb-library`, publié sur [PyPI](https://pypi.org/project/kmb-library/)), lance `python -m kmb_library scan`, récupère son rapport
`KMB-rapport_<PC>_<date>_<heure>.json` dans **Documents\KMB Library**, puis le téléverse sur le site, qui l'affiche
sans rien envoyer ni conserver.

| Document | Contenu |
|---|---|
| [One-Page-Projet.md](One-Page-Projet.md) | Besoin, solution, valeur, limites |
| [One-Page-Processus.md](One-Page-Processus.md) | Diagramme du processus et reprise |
| [Notes.md](Notes.md) | Choix, essais, usage de l'IA, apprentissages |
| [Verifications.md](Verifications.md) | Tableau des vérifications et preuves |
| [Presentation.md](Presentation.md) | Déroulé de la présentation et de la démonstration |
| [exemples/](exemples/) | Données avant/après, réponses de l'API, captures, simulations |
| [DEPLOIEMENT.md](DEPLOIEMENT.md) | Publier le site (GitHub Pages, Hostinger) et préparer le ZIP à télécharger |

## 1. Installation

Prérequis : Python 3.10 ou plus récent.

```bash
cd livrable_2
python -m venv .venv
# Windows : .venv\Scripts\activate      Linux / macOS : source .venv/bin/activate
pip install -e ".[dev]"
```

Assistant IA (facultatif) : copier `.env.example` en `.env` et renseigner `GROQ_API_KEY` (clé gratuite Groq, https://console.groq.com/keys ; une clé xAI Grok `XAI_API_KEY` fonctionne aussi). Sur le site public, l'IA passe par le relais `relais-ia/` (Cloudflare), qui garde la clé secrète.

## 2. Lancer un audit

Après l'installation (section 1, ou guide du site) :
```bash
kmb scan                         # 3 à 5 minutes ; le système est détecté automatiquement
kmb scan --nom "PC de Marie"     # nom affiché dans le rapport et dans le nom du fichier
kmb scan --anonymiser            # masque machine, comptes, IP, SSID Wi-Fi, chemins personnels
kmb scan --dossiers ~/Photos     # doublons cherchés dans un dossier précis
kmb scan --rapide --sans-maj      # plus rapide (analyse du disque limitée à 1 min)
kmb scan --sortie data           # enregistre dans ./data (lu par l'API locale) au lieu de Documents
```

Fichiers produits (par défaut dans **Documents\KMB Library**, dossier ouvert automatiquement à la fin ; détail dans [data/LISEZMOI.md](data/LISEZMOI.md)) :

| Fichier | Rôle |
|---|---|
| `KMB-rapport_PC-de-Marie_2026-10-18_14h30.json` | **le rapport** : à téléverser sur le site, qui l'affiche (aucun autre rapport n'est produit) |
| `donnees-brutes/donnees-brutes_PC-de-Marie_2026-10-18_14h30.json` | données non traitées (vérification) |

Droits élevés (facultatifs, pour vérifier **tous** les contrôles) : « Exécuter en tant qu'administrateur » sous Windows,
`sudo kmb scan` sous Linux et macOS. Sans ces droits, les contrôles concernés sont « non vérifiables » et ne comptent pas
dans le score. Le scan est **en lecture seule**.

## 3. Site web et API

```bash
uvicorn api.main:app --reload
```

* **Site public** : http://127.0.0.1:8000/ : accueil, guide d'installation pas à pas, « Analyser mon rapport » (le fichier est lu par le navigateur, rien n'est envoyé), questions fréquentes. Le même dossier `web/` se publie tel quel (voir [DEPLOIEMENT.md](DEPLOIEMENT.md)).
* **Tableau de bord relié à l'API** : http://127.0.0.1:8000/?mode=serveur : rapports du dossier `data/` (produits avec `kmb scan --sortie data` ou téléversés vers l'API), plan IA.
* **Documentation interactive de l'API** : http://127.0.0.1:8000/docs

| Endpoint | Rôle | Paramètres |
|---|---|---|
| `GET /scans` | Historique des scans | `machine`, `systeme`, `date_min`, `date_max`, `score_max`, `limit` |
| `GET /scans/{scan_id}` | Rapport complet (`dernier` = plus récent) | `scan_id` |
| `GET /scans/{scan_id}/findings` | Filtrer les problèmes | `severite` (répétable), `domaine`, `categorie`, `statut`, `recherche`, `limit` |
| `GET /scans/{scan_id}/logiciels` | Logiciels et cycle de vie | `recherche`, `cycle_de_vie`, `taille_min_mo`, `limit` |
| `GET /comparaison` | Avant / après | `ancien`, `nouveau` |
| `GET /statistiques` | Indicateurs, évolution, répartition par système | `machine`, `systeme` |
| `GET /scans/{scan_id}/rapport.html` | Rapport imprimable (« Enregistrer en PDF ») | `scan_id` |
| `POST /scans` · `DELETE /scans/{id}` | Téléverser / supprimer un rapport | corps JSON |
| `GET/POST /scans/{scan_id}/plan-ia` | Plan de correction de l'IA (Groq), vérifié | `regenerer` |
| `GET /connaissances[/{id}]` | Explication d'un contrôle (57) | `domaine`, `recherche` |

Erreurs : `404` introuvable, `422` paramètre invalide (avec le champ en cause), `409` doublon, `503` IA non configurée, `502` erreur du service d'IA.

## 4. Autres commandes

```bash
kmb comparer A.json B.json                 # avant / après en console
kmb envoyer A.json --api http://serveur:8000
kmb plan-ia A.json                         # plan IA (Groq) en console
pytest                                     # 78 tests (Linux et macOS simulés, IA, traductions, nouvelle version)
python scripts/construire_telechargements.py   # ZIP du code -> web/telechargements (--exe : programme Windows, non publié)
python scripts/capturer_exemples.py        # réponses de l'API -> exemples/appels_api
python scripts/capturer_ecrans.py          # captures du tableau de bord -> exemples/captures
python scripts/generer_simulations.py      # rapports Linux/macOS simulés -> exemples/simulations
python scripts/construire_traductions.py   # contrôle la base anglaise -> web/kb_en.json
python scripts/construire_page_anglaise.py # page anglaise web/en/index.html fabriquée à partir de la page française
python scripts/synchroniser_depot.py ../detection-des-failles-de-securite   # copie vers le dépôt GitHub, sans rien de privé
```

Automatisations GitHub ([.github/workflows/](.github/workflows/)) :
* `kmb-multiplateforme.yml` : tests et vrai scan anonymisé sur Windows, Ubuntu et macOS (Python 3.10 et 3.13) à chaque modification ;
* `site.yml` : publication du dossier `web/` sur GitHub Pages ;
* `publier.yml` : à la publication d'une version (release `vX.Y.Z`), tests puis envoi sur PyPI sans clé (« éditeur de confiance »).

## 5. Organisation du code

| Dossier | Rôle |
|---|---|
| `kmb_library/collectors/windows/`, `linux/`, `macos/` | **A. Collecte** propre à chaque système (9 collecteurs chacun), même forme de données en sortie |
| `kmb_library/collectors/common.py`, `wifi.py`, `hardware.py`, `duplicates.py` | **A. Collecte** commune (psutil, Wi-Fi, batterie, doublons) |
| `kmb_library/enrich/endoflife.py` | **A. Source externe** : cycle de vie de l'OS et des logiciels (API endoflife.date, cache 7 jours) |
| `kmb_library/enrich/pypi.py` | « Nouvelle version disponible » (PyPI, une fois par jour au plus) |
| `kmb_library/rules/` | **B. Traitement** : règles + `knowledge_base.json` (57 contrôles, variantes `*_linux` / `*_macos`) et sa traduction `knowledge_base_en.json` |
| `kmb_library/core/` | Modèles, scores, comparaison, anonymisation, orchestration |
| `kmb_library/ai/assistant.py` | Plan IA (Groq, ou xAI Grok) avec vérification des étapes et des commandes |
| `relais-ia/` | Relais Cloudflare de l'IA pour le site public (clé secrète, limites anti-abus) |
| `api/` | **C. Livraison** : API FastAPI (lit les fichiers JSON de `data/`) |
| `web/` | **C. Livraison** : site statique (guide + analyse dans le navigateur ; mode serveur via l'API) ; `web/en/` et `i18n-en.js` : version anglaise |
| `kmb_library/scanner_app.py` | Programme `KMB-Scanner.exe` (préparé pour une future version signée ; non publié) |
| `tests/` | 78 tests ; `tests/fixtures/` contient des sorties Linux/macOS représentatives |
